function myBirthYearFunc(){
        console.log("I was born in" + 1980);
    }//I was born in 1980

    function myBirthYearFunc(birthYearInput){
            console.log("I was born in" + birthYearInput);
        }//I was born in 1980

        function add(num1, num2){
                console.log("Summing Numbers!");
                console.log("num1 is: " + num1);
                console.log("num2 is: " + num2);
                var sum = num1 + num2;
                console.log(sum);
            }
            
//60            